//
//  MSMessageExtensionDataPublicKey+CoreDataClass.m
//  
//
//  Created by Distiller on 8/18/22.
//
//  This file was automatically generated and should not be edited.
//

#import "MSMessageExtensionDataPublicKey+CoreDataClass.h"

@implementation MSMessageExtensionDataPublicKey

@end
