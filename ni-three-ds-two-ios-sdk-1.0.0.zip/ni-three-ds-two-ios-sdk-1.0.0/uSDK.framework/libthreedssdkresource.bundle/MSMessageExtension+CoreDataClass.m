//
//  MSMessageExtension+CoreDataClass.m
//  
//
//  Created by Distiller on 8/18/22.
//
//  This file was automatically generated and should not be edited.
//

#import "MSMessageExtension+CoreDataClass.h"

@implementation MSMessageExtension

@end
