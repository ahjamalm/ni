//
//  ThreeDSSDKDataModel+CoreDataModel.h
//  
//
//  Created by Distiller on 8/18/22.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#import "MSMessageExtension+CoreDataClass.h"
#import "MSMessageExtensionData+CoreDataClass.h"
#import "MSMessageExtensionDataPublicKey+CoreDataClass.h"
#import "MSSDKPrompt+CoreDataClass.h"




