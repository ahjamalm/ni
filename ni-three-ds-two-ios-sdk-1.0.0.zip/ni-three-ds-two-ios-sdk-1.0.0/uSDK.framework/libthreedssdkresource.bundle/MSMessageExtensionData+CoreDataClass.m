//
//  MSMessageExtensionData+CoreDataClass.m
//  
//
//  Created by Distiller on 8/18/22.
//
//  This file was automatically generated and should not be edited.
//

#import "MSMessageExtensionData+CoreDataClass.h"

@implementation MSMessageExtensionData

@end
