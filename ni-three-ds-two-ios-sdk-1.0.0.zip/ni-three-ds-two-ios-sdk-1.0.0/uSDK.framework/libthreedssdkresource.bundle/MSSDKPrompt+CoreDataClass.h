//
//  MSSDKPrompt+CoreDataClass.h
//  
//
//  Created by Distiller on 8/18/22.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class MSMessageExtensionData;

NS_ASSUME_NONNULL_BEGIN

@interface MSSDKPrompt : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "MSSDKPrompt+CoreDataProperties.h"
